<div class="footer">
© 2022 - 2025 MINANCE<br>
<p style="font-size:10pt;">All rights reserved.</p>
<p style="font-size: 8pt;
    margin: 5px;
    color: #64bcc5;">developed by <a href="https://perfact.group/" target="_blank">PerFact.group</a> | Product AriOS Company</p>
</div>

</body>
</html>